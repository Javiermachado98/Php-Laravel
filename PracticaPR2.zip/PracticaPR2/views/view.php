<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario</title>
</head>

<body>
    <div>
        <h2>Formulario login</h2>
        <!--Puntos importantes: si tengo un formulario debo indicar hacia
        donde va mi formulario
        1. Puede ir vacio si lo proceso en el mismo archivo
        2. usar ?php echo $_SERVER['PHP_SELF'];
        3. El form debe llevar un method post o get
        4. IMPORTANTE revisar la funcion filterVar
        5. strlen() revisa la cantidad de caracteres-->
        <form action="index.php?action=processLogin" method="POST">
            <label for="fname">User name</label>
            <input type="text" placeholder="Enter name" id="fname" name="fname" required> <br>
            <label for="pwd">Password</label>
            <input type="password" placeholder="Enter password" id="pwd" name="pwd" required><br>
            <button type="submit">Login</button>
        </form>
    </div>
</body>

</html>